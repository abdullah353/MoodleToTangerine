<?php
$plugin->version  = 12013129;
$plugin->requires = 2010112400;  
$plugin->cron     = 0;
$plugin->release = '1.0 (Build: 12013129)';
$plugin->maturity = MATURITY_STABLE;