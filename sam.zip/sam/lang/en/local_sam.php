<?php
$string['pluginname'] = 'Web service template';
